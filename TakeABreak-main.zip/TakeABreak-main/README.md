![banner](https://user-images.githubusercontent.com/43648146/143238428-7741f46a-3667-487c-aae6-5688c050ed25.png)

<h1 align="center">Tackle procrastination by using self-destructing tabs and boost your productivity.</h1>
<p align="center">Ever took a break which lasted forever? Not anymore. <br>
Take controlled breaks and stop procrastinating forever. <br> <br>
All you have to do now is decide how long of a break you want, go to your favorite website and take a break till your time's up.</p>

https://user-images.githubusercontent.com/43648146/143237406-1f7c47f2-557c-442e-b789-299030dc7d96.mp4

# Check it out now at [breaks.eu.org](https://breaks.eu.org)

# Features
- Custom break time
- Add and save custom websites to use later
- Mobile-friendly
- No ads or trackers

> Inspired from Take a Five
